"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Building2, Car, User } from "lucide-react"

// Define the access control type
type AccessControl = {
  id: string
  customerName: string
  companiesLimit: number
  driversLimit: number
  vehiclesLimit: number
  companiesUsed: number
  driversUsed: number
  vehiclesUsed: number
}

interface ViewLimitsDialogProps {
  accessControl: AccessControl
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ViewLimitsDialog({ accessControl, open, onOpenChange }: ViewLimitsDialogProps) {
  // Calculate remaining credits
  const companiesRemaining = accessControl.companiesLimit - accessControl.companiesUsed
  const driversRemaining = accessControl.driversLimit - accessControl.driversUsed
  const vehiclesRemaining = accessControl.vehiclesLimit - accessControl.vehiclesUsed

  // Calculate usage percentages
  const companyUsagePercent = (accessControl.companiesUsed / accessControl.companiesLimit) * 100
  const driverUsagePercent = (accessControl.driversUsed / accessControl.driversLimit) * 100
  const vehicleUsagePercent = (accessControl.vehiclesUsed / accessControl.vehiclesLimit) * 100

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Access Limits for {accessControl.customerName}</DialogTitle>
          <DialogDescription>Current usage and remaining credits for WASL API services</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 my-2">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Building2 className="h-5 w-5 mr-2 text-blue-500" />
                      <span className="font-medium">Company API</span>
                    </div>
                    <div className="text-sm font-medium">
                      {accessControl.companiesUsed} / {accessControl.companiesLimit}
                    </div>
                  </div>
                  <Progress value={companyUsagePercent} className="h-2" />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Used: {accessControl.companiesUsed}</span>
                    <span>Remaining: {companiesRemaining}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <User className="h-5 w-5 mr-2 text-green-500" />
                      <span className="font-medium">Driver API</span>
                    </div>
                    <div className="text-sm font-medium">
                      {accessControl.driversUsed} / {accessControl.driversLimit}
                    </div>
                  </div>
                  <Progress value={driverUsagePercent} className="h-2" />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Used: {accessControl.driversUsed}</span>
                    <span>Remaining: {driversRemaining}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Car className="h-5 w-5 mr-2 text-orange-500" />
                      <span className="font-medium">Vehicle API</span>
                    </div>
                    <div className="text-sm font-medium">
                      {accessControl.vehiclesUsed} / {accessControl.vehiclesLimit}
                    </div>
                  </div>
                  <Progress value={vehicleUsagePercent} className="h-2" />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Used: {accessControl.vehiclesUsed}</span>
                    <span>Remaining: {vehiclesRemaining}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="text-sm text-muted-foreground">
            <p>
              These limits represent the maximum number of API calls the customer can make to each WASL API service.
              When a limit is reached, the customer will need to request an increase or wait for the next billing cycle.
            </p>
          </div>
        </div>

        <DialogFooter className="flex justify-between">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button>Adjust Limits</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
