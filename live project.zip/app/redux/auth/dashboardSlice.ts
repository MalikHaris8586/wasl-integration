import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

interface LimitType {
  used: number;
  allowed: number;
  remaining: number;
}

interface ApiCalls {
  company: LimitType;
  driver: LimitType;
  vehicle: LimitType;
}

interface Activity {
  id: number;
  action: string;
  entity: string;
  status: string;
  time: string;
}

interface DashboardState {
  companies_count: number;
  drivers_count: number;
  vehicles_count: number;
  api_calls: ApiCalls;
  activities: Activity[];
  loading: boolean;
  error: string | null;
}

const initialState: DashboardState = {
  companies_count: 0,
  drivers_count: 0,
  vehicles_count: 0,
  api_calls: {
    company: { allowed: 0, used: 0, remaining: 0 },
    driver: { allowed: 0, used: 0, remaining: 0 },
    vehicle: { allowed: 0, used: 0, remaining: 0 },
  },
  activities: [],
  loading: false,
  error: null,
};

export const fetchDashboard = createAsyncThunk(
  "dashboard/fetch",
  async ({ _, thunkAPI, token }: any) => {
    try {
      const response = await fetch(
        "https://wasl-api.tracking.me/api/genesis/wasl/dashboard",
        {
          headers: {
            Authorization: `Bearer ${token}`,
               Accept: "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error("Unauthorized or fetch failed");
      }

      const data = await response.json();
      
      console.log("API Response Data:", data);
      return data;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

const dashboardSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchDashboard.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDashboard.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;

        // Update values from API
        state.companies_count = action.payload.companies_count;
        state.drivers_count = action.payload.drivers_count;
        state.vehicles_count = action.payload.vehicles_count;
        state.api_calls = action.payload.api_calls;
        state.activities = action.payload.activities;
      })
      .addCase(fetchDashboard.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default dashboardSlice.reducer;
