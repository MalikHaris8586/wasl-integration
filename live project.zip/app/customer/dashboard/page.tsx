"use client";

import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../../redux/store";
import { fetchDashboard } from "../../redux/auth/dashboardSlice";
import {  fetchApiUsage} from "../../redux/auth/apiUsageSlice";
import { useState, useEffect } from "react";
import { Activity, Building2, Car, Clock, MapPin, User } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ApiUsageTabContent from "./ApiUsageTabContent";

export default function CustomerDashboard() {
  // Mock data
  const dispatch = useAppDispatch();
  const { api_calls, activities, loading, error } = useSelector(
    (state: RootState) => state.dashboard
  );
  const [activeTab, setActiveTab] = useState("overview");
  const token = useSelector((state: any) => state.auth.token);

  console.log("token", token);

useEffect(()=>{
  if (token){
    dispatch(fetchDashboard({token}));
  }
},[token,dispatch])


  if (loading) return <p>Loading dashboard data...</p>;
  if (error) return <p>Error: {error}</p>;

  // Mock API usage data
  // const apiUsage = [
  //   {
  //     date: "2023-04-16",
  //     companies: 2,
  //     drivers: 5,
  //     vehicles: 3,
  //     locations: 120,
  //   },
  //   {
  //     date: "2023-04-17",
  //     companies: 1,
  //     drivers: 3,
  //     vehicles: 2,
  //     locations: 115,
  //   },
  //   {
  //     date: "2023-04-18",
  //     companies: 3,
  //     drivers: 7,
  //     vehicles: 4,
  //     locations: 130,
  //   },
  //   {
  //     date: "2023-04-19",
  //     companies: 0,
  //     drivers: 2,
  //     vehicles: 1,
  //     locations: 110,
  //   },
  //   {
  //     date: "2023-04-20",
  //     companies: 2,
  //     drivers: 4,
  //     vehicles: 3,
  //     locations: 125,
  //   },
  // ];

  // Mock recent activities
  const recentActivities = [
    {
      id: 1,
      action: "Company registered",
      entity: "Acme Subsidiary",
      status: "success",
      time: "2 hours ago",
    },
    {
      id: 2,
      action: "Driver registered",
      entity: "Ahmed Abdullah",
      status: "success",
      time: "5 hours ago",
    },
    {
      id: 3,
      action: "Vehicle registered",
      entity: "Truck 003",
      status: "pending",
      time: "1 day ago",
    },
    {
      id: 4,
      action: "Location posted",
      entity: "Van 002",
      status: "success",
      time: "1 day ago",
    },
    {
      id: 5,
      action: "Company registration",
      entity: "XYZ Branch",
      status: "error",
      time: "2 days ago",
    },
  ];

  // const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="text-sm text-muted-foreground">
          Last updated: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()}
        </div>
      </div>

      <Tabs
        defaultValue="overview"
        value={activeTab}
        onValueChange={setActiveTab}
        className="space-y-4"
      >
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="usage">API Usage</TabsTrigger>
          <TabsTrigger value="activity">Recent Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="shadow-md">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Company Limit
                </CardTitle>
                <Building2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {api_calls.company.used} / {api_calls.company.allowed}
                </div>
                <Progress
                  value={
                    (api_calls.company.used /
                      (api_calls.company.allowed || 1)) *
                    100
                  }
                  className="mt-2 h-2"
                  indicatorClassName="bg-wialon-blue"
                />
                <p className="mt-2 text-xs text-muted-foreground">
                  {api_calls.company.remaining} remaining
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Driver Limit
                </CardTitle>
                <User className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {api_calls.driver.used} / {api_calls.driver.allowed}
                </div>
                <Progress
                  value={
                    (api_calls.driver.used / (api_calls.driver.allowed || 1)) *
                    100
                  }
                  className="mt-2 h-2"
                  indicatorClassName="bg-wialon-red"
                />
                <p className="mt-2 text-xs text-muted-foreground">
                  {api_calls.driver.remaining} remaining
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Vehicle Limit
                </CardTitle>
                <Car className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {api_calls.vehicle.used} / {api_calls.vehicle.allowed}
                </div>
                <Progress
                  value={
                    (api_calls.vehicle.used /
                      (api_calls.vehicle.allowed || 1)) *
                    100
                  }
                  className="mt-2 h-2"
                  indicatorClassName="bg-wialon-blue"
                />
                <p className="mt-2 text-xs text-muted-foreground">
                  {api_calls.vehicle.remaining} remaining
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>



        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>
                Your latest WASL integration activities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activities.length === 0 && (
                  <p>No recent activities available.</p>
                )}
                {activities.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-4">
                    <div
                      className={`w-2 h-2 mt-2 rounded-full ${
                        activity.status === "success"
                          ? "bg-green-500"
                          : activity.status === "pending"
                          ? "bg-yellow-500"
                          : "bg-red-500"
                      }`}
                    ></div>
                    <div>
                      <p className="text-sm font-medium">
                        {activity.action}: {activity.entity}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {activity.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => setActiveTab("overview")}
              >
                Back to Overview
              </Button>
            </CardFooter>
          </Card>
        </TabsContent> 





        <TabsContent value="usage" className="space-y-4">
              <ApiUsageTabContent/>
     
        </TabsContent> 



        

         <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>All your recent WASL integration activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-4 border-b pb-4 last:border-0">
                    <div className="mt-0.5">
                      {activity.action.includes("Company") ? (
                        <Building2 className="h-5 w-5 text-blue-500" />
                      ) : activity.action.includes("Driver") ? (
                        <User className="h-5 w-5 text-green-500" />
                      ) : activity.action.includes("Vehicle") ? (
                        <Car className="h-5 w-5 text-orange-500" />
                      ) : activity.action.includes("Location") ? (
                        <MapPin className="h-5 w-5 text-red-500" />
                      ) : (
                        <Activity className="h-5 w-5 text-gray-500" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">{activity.action}</p>
                        <div
                          className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            activity.status === "success"
                              ? "bg-green-100 text-green-800"
                              : activity.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {activity.status.charAt(0).toUpperCase() + activity.status.slice(1)}
                        </div>
                      </div>
                      <p className="text-sm">{activity.entity}</p>
                      <div className="flex items-center mt-1 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3 mr-1" />
                        {activity.time}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" size="sm" className="w-full">
                Load More
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>  
      </Tabs>
    </div>
  );
}
